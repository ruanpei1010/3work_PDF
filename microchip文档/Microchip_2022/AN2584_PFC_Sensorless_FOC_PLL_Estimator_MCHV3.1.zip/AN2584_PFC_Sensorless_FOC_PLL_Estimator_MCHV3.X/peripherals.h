#ifndef PERIPHERALS_H
#define PERIPHERALS_H

void initLEDPorts(void);
void initInternalOpamps(void);
void initFaultComparator(void);
void initUARTPorts(void);
void initADC(void);
void enableADC(void);
void initPWM(void);
void enablePWM(void);
void disablePWM(void);
#endif