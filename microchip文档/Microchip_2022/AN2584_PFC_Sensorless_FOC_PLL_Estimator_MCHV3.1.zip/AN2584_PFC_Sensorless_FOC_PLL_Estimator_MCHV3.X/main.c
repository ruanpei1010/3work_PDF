#include <xc.h>
#include "userparams.h"
#include "peripherals.h"
#include "foc.h"
#include "mc_Lib.h"
#include <sys/attribs.h>

// <editor-fold defaultstate="collapsed" desc="Configuration Bits">

/*** DEVCFG0 ***/

#pragma config DEBUG =      OFF
#pragma config JTAGEN =     OFF
#pragma config ICESEL =     ICS_PGx2
#pragma config TRCEN =      OFF
#pragma config BOOTISA =    MIPS32
#pragma config FSLEEP =     OFF
#pragma config DBGPER =     PG_ALL
#pragma config SMCLR =      MCLR_NORM
#pragma config SOSCGAIN =   GAIN_2X
#pragma config SOSCBOOST =  ON
#pragma config POSCGAIN =   GAIN_LEVEL_3
#pragma config POSCBOOST =  ON
#pragma config EJTAGBEN =   NORMAL
#pragma config CP =         OFF

/*** DEVCFG1 ***/

#pragma config FNOSC =      SPLL
#pragma config DMTINTV =    WIN_127_128
#pragma config FSOSCEN =    ON
#pragma config IESO =       ON
#pragma config POSCMOD =    EC
#pragma config OSCIOFNC =   OFF
#pragma config FCKSM =      CSECME
#pragma config WDTPS =      PS1048576
#pragma config WDTSPGM =    STOP
#pragma config FWDTEN =     OFF
#pragma config WINDIS =     NORMAL
#pragma config FWDTWINSZ =  WINSZ_25
#pragma config DMTCNT =     DMT31
#pragma config FDMTEN =     OFF
/*** DEVCFG2 ***/

#pragma config FPLLIDIV =   DIV_3
#pragma config FPLLRNG =    RANGE_5_10_MHZ
#pragma config FPLLICLK =   PLL_POSC
#pragma config FPLLMULT =   MUL_60
#pragma config FPLLODIV =   DIV_4
#pragma config VBATBOREN =  ON
#pragma config DSBOREN =    ON
#pragma config DSWDTPS =    DSPS32
#pragma config DSWDTOSC =   LPRC
#pragma config DSWDTEN =    OFF
#pragma config FDSEN =      ON
#pragma config BORSEL =     HIGH
#pragma config UPLLEN =     OFF
/*** DEVCFG3 ***/

#pragma config USERID =     0xffff
#pragma config FUSBIDIO2 =   ON
#pragma config FVBUSIO2 =  ON
#pragma config PGL1WAY =    ON
#pragma config PMDL1WAY =   ON
#pragma config IOL1WAY =    ON
#pragma config FUSBIDIO1 =   ON
#pragma config FVBUSIO1 =  ON
#pragma config PWMLOCK =  OFF

/*** BF1SEQ0 ***/

#pragma config TSEQ =       0x0000
#pragma config CSEQ =       0xffff
// </editor-fold>


extern mcParam_SinCos					    mcApp_SincosParam;
extern mcParam_SVPWM                       mcApp_SVGenParam;


int main(void)
{
   
 
      // <editor-fold defaultstate="collapsed" desc="Make kseg0 Cacheable">
    register unsigned long tmp_cache;
    asm("mfc0 %0,$16,0" :  "=r"(tmp_cache));
    tmp_cache = (tmp_cache & ~7) | 3;
    asm("mtc0 %0,$16,0" :: "r" (tmp_cache));
    // </editor-fold>
        CHECONbits.PFMWS=3; // Flash wait states = 3 CPU clock cycles
        CHECONbits.PREFEN = 1; // Enable Prefetch Cache
      INTCONbits.MVEC = 1;
    __builtin_mtc0(12,0,(__builtin_mfc0(12,0) | 0x0001)); // Global Interrupt Enable
    initLEDPorts(); // Initialize I/O Ports that drive LED D1 and D2
    initUARTPorts(); // Initialize I/O Ports that drive UART TX and RX 
    initADC(); // Initialize ADC
    initPWM();// Initialize PWM
    enableADC();// enable ADC
    
    TRISGbits.TRISG13 = 0;
    
#ifdef INTERNAL_OPAMP
    initInternalOpamps();
    initFaultComparator();
#endif 
    //////////////////////////////////////
    // X2CScope_Init();
    //////////////////////////////////////
    X2CScope_Init();
   while(BTN1)
   {
            //////////////////////////////////////
        // X2CScope_Communicate();
        //////////////////////////////////////
        X2CScope_Communicate();
     X2CScope_Update();  
   }
   
#ifdef MC_ENABLE
    mcApp_Control.bit.Btn1Pressed = 1;
    mcApp_Control.bit.OpenLoop = 1;
    mcApp_Control.bit.ChangeMode = 1;
    mcApp_InitControlParameters();
	mcApp_InitEstimParm();
	mcApp_SincosParam.Angle = 0;
	mcApp_SVGenParam.PWMPeriod = (float)MAX_DUTY;
    enablePWM();
#endif

#ifdef PFC_ENABLE
    ANSELEbits.ANSE13 = 0;
    TRISEbits.TRISE13 = 0;
    LATEbits.LATE13 = 1;
    pfcApp_Init();
    enablePWM();
#endif 
    
    
	while(1)
    {
        //////////////////////////////////////
        // X2CScope_Communicate();
        //////////////////////////////////////
        X2CScope_Communicate();
       
    }
     
}

void __ISR(_ADC_DATA3_VECTOR, ipl3auto)mcApp_ADCISR(void)
{
    
    mcApp_ADCISRTasks();
    X2CScope_Update();
    IFS3bits.AD1D3IF = 0; 
     
}

void __ISR(_ADC_DATA4_VECTOR, ipl4auto)pfcApp_ADCISR(void)
{
   
    pfcApp_ADCISRTasks();
    IFS3bits.AD1D4IF = 0; 
    
}
