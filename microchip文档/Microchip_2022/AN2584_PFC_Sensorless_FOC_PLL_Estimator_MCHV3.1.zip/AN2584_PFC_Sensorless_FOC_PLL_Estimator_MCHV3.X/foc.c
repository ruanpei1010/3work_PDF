#include "userparams.h"
#include <math.h>
#include <xc.h>
#include "foc.h"
#include "mc_Lib.h"


mcParam_PIController     			mcApp_Q_PIParam;      // Parameters for Q axis Current PI Controller 
mcParam_PIController     			mcApp_D_PIParam;      // Parameters for D axis Current PI Controller 
mcParam_PIController     			mcApp_Speed_PIParam;  // Parameters for Speed PI Controller 
mcParam_FOC							mcApp_focParam;       // Parameters related to Field Oriented Control
mcParam_SinCos					    mcApp_SincosParam;    // Parameters related to Sine/Cosine calculator
mcParam_SVPWM 						mcApp_SVGenParam;     // Parameters related to Space Vector PWM
mcParam_ControlRef 					mcApp_ControlParam;   // Parameters related to Current and Speed references
mcParam_PLLEstimator                mcApp_EstimParam;     // Parameters related to PLL Estimator
mcParam_AlphaBeta                   mcApp_I_AlphaBetaParam; // Alpha and Beta (2 Phase Stationary Frame) axis Current values
mcParam_DQ                          mcApp_I_DQParam;// D and Q axis (2 Phase Rotating Frame) current values
mcParam_ABC                         mcApp_I_ABCParam; // A,B,C axis (3 Phase Stationary Frame) current values
mcParam_AlphaBeta                   mcApp_V_AlphaBetaParam; // Alpha and Beta (2 Phase Stationary Frame) axis voltage values
mcParam_DQ                          mcApp_V_DQParam;// D and Q axis (2 Phase Rotating Frame) voltage values

float 								Startup_Ramp_Angle_Rads_Per_Sec = 0; 	// ramp angle variable for initial ramp 
unsigned int 						Startup_Lock_Count = 0; 				// lock variable for initial ramp 

short        						potReading;
short                               phaseCurrentA;
short                               phaseCurrentB;

short 								POLARITY;
float								DoControl_Temp1, DoControl_Temp2;


//Cumulative value is initialized to (estimated offset value * 2^MOVING_AVG_WINDOW_SIZE) which helps in expedited tracking of offset value without
//waiting for all the 2^MOVING_AVG_WINDOW_SIZE samples.

unsigned int cumulative_sum_phaseA = (CURRENT_OFFSET_INIT << MOVING_AVG_WINDOW_SIZE); 
unsigned int cumulative_sum_phaseB = (CURRENT_OFFSET_INIT << MOVING_AVG_WINDOW_SIZE);
unsigned int moving_average_phaseA = 0;
unsigned int moving_average_phaseB = 0;





// *****************************************************************************
// *****************************************************************************
// Section: MC ADC ISR TASKS
// *****************************************************************************
// *****************************************************************************
void mcApp_ADCISRTasks(void)
{
	phaseCurrentA = ADCDATA3;// Phase Current A measured using ADC3
    phaseCurrentB = ADCDATA1;// Phase Current B measured using ADC1
    potReading = ADCDATA15;// Speed Potentiometer measured using ADC7 (Shared ADC)  
    mcApp_focParam.DCBusVoltage = (float)ADCDATA10* VOLTAGE_ADC_TO_PHY_RATIO; // Reads and translates to actual bus voltage
    mcApp_focParam.MaxPhaseVoltage = (float)(mcApp_focParam.DCBusVoltage*ONE_BY_SQRT3); 
	
	/* Moving Average Filter is implemented to calculate the current offset. Window size of the moving average filter = 2^MOVING_AVG_WINDOW_SIZE
	cumulative_sum_phaseX(n) = cumulative_sum_phaseX(n-1) + phaseCurrentX(n) - moving_average_phaseX(n-1)
	moving_average_phaseX(n) =  cumulative_sum_phaseX(n)/(2^MOVING_AVG_WINDOW_SIZE) */

	
	cumulative_sum_phaseA  = cumulative_sum_phaseA + phaseCurrentA - moving_average_phaseA;
    moving_average_phaseA  = cumulative_sum_phaseA >> MOVING_AVG_WINDOW_SIZE;
    
	/*Bounding the offset value */
	if(moving_average_phaseA > CURRENT_OFFSET_MAX)
    {
        moving_average_phaseA = CURRENT_OFFSET_MAX;
    }
    else if (moving_average_phaseA < CURRENT_OFFSET_MIN)
    {
        moving_average_phaseA = CURRENT_OFFSET_MIN;
    }
	
	
	cumulative_sum_phaseB  = cumulative_sum_phaseB + phaseCurrentB - moving_average_phaseB;
    moving_average_phaseB  = cumulative_sum_phaseB >> MOVING_AVG_WINDOW_SIZE;
	
	/*Bounding the offset value */
	if(moving_average_phaseB > CURRENT_OFFSET_MAX)
    {
        moving_average_phaseB = CURRENT_OFFSET_MAX;
    }
    else if (moving_average_phaseB < CURRENT_OFFSET_MIN)
    {
        moving_average_phaseB = CURRENT_OFFSET_MIN;
    }
	
    phaseCurrentA = (phaseCurrentA - moving_average_phaseA); // Removing the offset
    phaseCurrentB = (phaseCurrentB - moving_average_phaseB);

    mcApp_I_ABCParam.a = (float)phaseCurrentA*ADC_CURRENT_SCALE * (-1); 
    mcApp_I_ABCParam.b = (float)phaseCurrentB*ADC_CURRENT_SCALE * (-1);
    
    mcLib_ClarkeTransform(&mcApp_I_ABCParam, &mcApp_I_AlphaBetaParam);
   
    mcLib_ParkTransform(&mcApp_I_AlphaBetaParam,  &mcApp_SincosParam, 
                        &mcApp_I_DQParam);
    
    mcLib_PLLEstimator(&mcApp_EstimParam, &mcApp_SincosParam, &mcApp_focParam, 
                       &mcApp_ControlParam, &mcApp_I_AlphaBetaParam, 
                       &mcApp_V_AlphaBetaParam);
       
    // Calculate control values
    MC_APP_MC_DoControl();
  

    MC_APP_MC_CalculateParkAngle();

    /* if open loop */
    if(mcApp_Control.bit.OpenLoop == 1)
    {
        /* the angle is given by parkparm */
        mcApp_SincosParam.Angle = mcApp_focParam.OpenLoopAngle;
       
    } 
    else
    {
        /* if closed loop, angle generated by estim */
        mcApp_SincosParam.Angle = mcApp_EstimParam.qRho;
    }
    mcLib_SinCosGen(&mcApp_SincosParam);
 
    mcLib_InvParkTransform(&mcApp_V_DQParam,&mcApp_SincosParam, &mcApp_V_AlphaBetaParam);
    
    mcLib_SVPWMGen(&mcApp_V_AlphaBetaParam , &mcApp_SVGenParam);
	PDC1 = (uint16_t) mcApp_SVGenParam.dPWM_A;
    PDC2 = (uint16_t) mcApp_SVGenParam.dPWM_B;
	PDC3 = (uint16_t) mcApp_SVGenParam.dPWM_C;
}


// *****************************************************************************
// *****************************************************************************
// Section: MC FOC Control Routine
// *****************************************************************************
// *****************************************************************************

void MC_APP_MC_DoControl( void )
{
  
	  
    if( mcApp_Control.bit.OpenLoop )
    {
        // OPENLOOP:  force rotating angle,Vd,Vq
        if( mcApp_Control.bit.ChangeMode )
        {
            // just changed to openloop
            mcApp_Control.bit.ChangeMode = 0;
            // synchronize angles

            // VqRef & VdRef not used
            mcApp_ControlParam.IqRef = 0;
            mcApp_ControlParam.IdRef = 0;

			// reinit vars for initial speed ramp
			Startup_Lock_Count = 0;
			Startup_Ramp_Angle_Rads_Per_Sec = 0;
        }
        
        // q current reference is equal to the vel reference
        // while d current reference is equal to 0
        // for maximum startup torque, set the q current to maximum acceptable
        // value represents the maximum peak value
        mcApp_ControlParam.IqRef    = Q_CURRENT_REF_OPENLOOP;
       	
        // PI control for Q
        mcApp_Q_PIParam.qInMeas = mcApp_I_DQParam.q;
        mcApp_Q_PIParam.qInRef  = mcApp_ControlParam.IqRef;
        mcLib_CalcPI(&mcApp_Q_PIParam);
        mcApp_V_DQParam.q = mcApp_Q_PIParam.qOut;
       
        // PI control for D
        mcApp_D_PIParam.qInMeas = mcApp_I_DQParam.d;
        mcApp_D_PIParam.qInRef  = mcApp_ControlParam.IdRef;
        mcLib_CalcPI(&mcApp_D_PIParam);
        mcApp_V_DQParam.d = mcApp_D_PIParam.qOut;
    } 
    else
    // Closed Loop Vector Control
	{ 
        LATFSET=0x0020; // Set LED D17 to indicate closed loop operation of the motor
        
		if( mcApp_Control.bit.ChangeMode )
        {
            // just changed from openloop
            mcApp_Control.bit.ChangeMode = 0;
			mcApp_Speed_PIParam.qdSum = mcApp_ControlParam.IqRef;
            mcApp_ControlParam.VelRef = END_SPEED_RADS_PER_SEC_ELEC;
            mcApp_D_PIParam.qInRef = 0.0;
            mcApp_ControlParam.IdRef = 0.0;
        }             
        
        
             mcApp_ControlParam.VelInput =(float)((float)potReading * POT_ADC_COUNT_FW_SPEED_RATIO);
        
        mcApp_ControlParam.Diff =  mcApp_ControlParam.VelInput - mcApp_ControlParam.VelRef;
    
      
       //Speed Rate Limiter implementation.    
        if(mcApp_ControlParam.Diff >=CL_SPEED_HYSTERESIS)
        {
             mcApp_ControlParam.VelRef+=CL_SPEED_RAMP_RATE_DELTA;   
        }
        else if(mcApp_ControlParam.Diff <=-CL_SPEED_HYSTERESIS)
        {
             mcApp_ControlParam.VelRef-=CL_SPEED_RAMP_RATE_DELTA; 
        }
        else
        {
             mcApp_ControlParam.VelRef = mcApp_ControlParam.VelInput;
        }
        
		if(mcApp_ControlParam.VelRef < END_SPEED_RADS_PER_SEC_ELEC)
        {
            mcApp_ControlParam.VelRef = END_SPEED_RADS_PER_SEC_ELEC;
        }
        
       
        
        //if TORQUE MODE skip the speed and Field Weakening controller               
#ifndef	TORQUE_MODE
       	// Execute the velocity control loop
		mcApp_Speed_PIParam.qInMeas = mcApp_EstimParam.qVelEstim;
    	mcApp_Speed_PIParam.qInRef  = mcApp_ControlParam.VelRef;
    	mcLib_CalcPI(&mcApp_Speed_PIParam);
    	mcApp_ControlParam.IqRef = mcApp_Speed_PIParam.qOut;



		
		// Implement Field Weakening if Speed input is greater than the base speed of the motor
		
		if(mcApp_ControlParam.VelRef > NOMINAL_SPEED_RAD_PER_SEC_ELEC)
        {
			 mcApp_focParam.VdqNorm = sqrt((mcApp_V_DQParam.d*mcApp_V_DQParam.d)+ (mcApp_V_DQParam.q*mcApp_V_DQParam.q));
			 //Vqref = sqrt(Vmax^2 -Vd^2 )
			 mcApp_focParam.VdSquaredDenorm = (mcApp_V_DQParam.d*mcApp_V_DQParam.d*mcApp_focParam.MaxPhaseVoltage*mcApp_focParam.MaxPhaseVoltage);
             mcApp_focParam.MaxVoltageCircleSquared = 0.98 * mcApp_focParam.MaxPhaseVoltage * mcApp_focParam.MaxPhaseVoltage;
             mcApp_focParam.VqSquaredDenorm = mcApp_focParam.MaxVoltageCircleSquared - mcApp_focParam.VdSquaredDenorm;
             if(mcApp_focParam.VqSquaredDenorm < 0)
             {
             mcApp_focParam.VqSquaredDenorm = 0;
             }
             mcApp_focParam.VqRefVoltage = sqrt(mcApp_focParam.VqSquaredDenorm);  
			 
			 //Calculating Flux Weakening value of Id, Id_flux_Weakening = (Vqref- Rs*Iq - BEMF)/omega*Ls

             mcApp_ControlParam.IdRef = (mcApp_focParam.VqRefVoltage - (MOTOR_PER_PHASE_RESISTANCE * mcApp_ControlParam.IqRef) 
									-(mcApp_ControlParam.VelRef  * MOTOR_BACK_EMF_CONSTANT_Vpeak_PHASE_RAD_PER_SEC_ELEC))/(mcApp_ControlParam.VelRef  * MOTOR_PER_PHASE_INDUCTANCE);
									
									
			 // Limit Id such that MAX_FW_NEGATIVE_ID_REF < Id < 0
			if(mcApp_ControlParam.IdRef > 0)
				mcApp_ControlParam.IdRef = 0; 
        
			if(mcApp_ControlParam.IdRef < MAX_FW_NEGATIVE_ID_REF)
				mcApp_ControlParam.IdRef = MAX_FW_NEGATIVE_ID_REF;
			
			// Limit Q axis current such that sqrt(Id^2 +Iq^2) <= MAX_MOTOR_CURRENT
			mcApp_ControlParam.IqRefmax = sqrt((MAX_MOTOR_CURRENT_SQUARED) - (mcApp_ControlParam.IdRef*mcApp_ControlParam.IdRef));		
		}
		else
		{
			mcApp_ControlParam.IdRef = 0;
			mcApp_ControlParam.IqRefmax = MAX_MOTOR_CURRENT;
		}
		
		
#else
        mcApp_ControlParam.IqRef = Q_CURRENT_REF_OPENLOOP; // During torque mode, Iq = Open Loop Iq, Id = 0
		mcApp_ControlParam.IdRef = 0;
        mcApp_ControlParam.IqRefmax = MAX_MOTOR_CURRENT;
#endif  // endif for TORQUE_MODE
		
        // PI control for D
        mcApp_D_PIParam.qInMeas = mcApp_I_DQParam.d;          // This is in Amps
        mcApp_D_PIParam.qInRef  = mcApp_ControlParam.IdRef;      // This is in Amps
        mcLib_CalcPI(&mcApp_D_PIParam);
        mcApp_V_DQParam.d    =  mcApp_D_PIParam.qOut;          // This is in %. If should be converted to volts, multiply with DCBus/sqrt(3)

        // dynamic d-q adjustment
        // with d component priority
        // vq=sqrt (vs^2 - vd^2)
        // limit vq maximum to the one resulting from the calculation above
        DoControl_Temp2 = mcApp_D_PIParam.qOut * mcApp_D_PIParam.qOut;
        DoControl_Temp1 = 0.98 - DoControl_Temp2;
        mcApp_Q_PIParam.qOutMax = sqrt(DoControl_Temp1);        
		
		//Limit Q axis current
		if(mcApp_ControlParam.IqRef>mcApp_ControlParam.IqRefmax)
		{
		mcApp_ControlParam.IqRef = mcApp_ControlParam.IqRefmax;
		}
		
        // PI control for Q
        mcApp_Q_PIParam.qInMeas = mcApp_I_DQParam.q;          // This is in Amps
        mcApp_Q_PIParam.qInRef  = mcApp_ControlParam.IqRef;      // This is in Amps
        mcLib_CalcPI(&mcApp_Q_PIParam);
        mcApp_V_DQParam.q    = mcApp_Q_PIParam.qOut;          // This is in %. If should be converted to volts, multiply with DCBus/sqrt(3)       

    }
}
// *****************************************************************************
// *****************************************************************************
// Section: MC FOC Rotor Angle Calculation
// *****************************************************************************
// *****************************************************************************

void MC_APP_MC_CalculateParkAngle(void)
{
    // If open loop
	if(mcApp_Control.bit.OpenLoop)	
	{
		// begin with the lock sequence, for field alignment. The rotor is locked at angle = 0 for LOCK_COUNT_FOR_LOCK_TIME ~ 2 seconds
		if (Startup_Lock_Count < LOCK_COUNT_FOR_LOCK_TIME)
			Startup_Lock_Count++;
	    // then ramp up till the end speed
		else if (Startup_Ramp_Angle_Rads_Per_Sec < END_SPEED_RADS_PER_SEC_ELEC_IN_LOOPTIME)
			Startup_Ramp_Angle_Rads_Per_Sec+=OPENLOOP_RAMPSPEED_INCREASERATE;
		else // switch to closed loop
		{
#ifndef OPEN_LOOP_FUNCTIONING
            mcApp_Control.bit.ChangeMode = 1;
            mcApp_Control.bit.OpenLoop = 0;
#endif
		}
		
		// the angle set depends on startup ramp
		mcApp_focParam.OpenLoopAngle += Startup_Ramp_Angle_Rads_Per_Sec;
        
        if(mcApp_focParam.OpenLoopAngle >= SINGLE_ELEC_ROT_RADS_PER_SEC)
            mcApp_focParam.OpenLoopAngle = mcApp_focParam.OpenLoopAngle - SINGLE_ELEC_ROT_RADS_PER_SEC;        
	}
	else // switched to closed loop
	{
   	    // in closed loop slowly decrease the offset add to the estimated angle
   	    if(mcApp_EstimParam.RhoOffset>(M_PI/(float)32767))
            mcApp_EstimParam.RhoOffset = mcApp_EstimParam.RhoOffset - ((M_PI/(float)32767)) ; 
	}
	return;
}


// *****************************************************************************
// *****************************************************************************
// Section: MC PI Controller Routines
// *****************************************************************************
// *****************************************************************************

void mcApp_InitControlParameters(void)
{
	// PI D Term     
    mcApp_D_PIParam.qKp = D_CURRCNTR_PTERM;       
    mcApp_D_PIParam.qKi = D_CURRCNTR_ITERM;              
    mcApp_D_PIParam.qKc = D_CURRCNTR_CTERM;       
    mcApp_D_PIParam.qOutMax = D_CURRCNTR_OUTMAX;
    mcApp_D_PIParam.qOutMin = -mcApp_D_PIParam.qOutMax;

    mcLib_InitPI(&mcApp_D_PIParam);

    // PI Q Term 
    mcApp_Q_PIParam.qKp = Q_CURRCNTR_PTERM;    
    mcApp_Q_PIParam.qKi = Q_CURRCNTR_ITERM;
    mcApp_Q_PIParam.qKc = Q_CURRCNTR_CTERM;
    mcApp_Q_PIParam.qdSum = 0;
    mcApp_Q_PIParam.qOutMax = Q_CURRCNTR_OUTMAX;
    mcApp_Q_PIParam.qOutMin = -mcApp_Q_PIParam.qOutMax;

    mcLib_InitPI(&mcApp_Q_PIParam);

    // PI Qref Term
    mcApp_Speed_PIParam.qKp = SPEEDCNTR_PTERM;       
    mcApp_Speed_PIParam.qKi = SPEEDCNTR_ITERM;       
    mcApp_Speed_PIParam.qKc = SPEEDCNTR_CTERM;       
    mcApp_Speed_PIParam.qOutMax = SPEEDCNTR_OUTMAX;   
    mcApp_Speed_PIParam.qOutMin = -mcApp_Speed_PIParam.qOutMax;

    mcLib_InitPI(&mcApp_Speed_PIParam);
	
	
	
	return;
}
// *****************************************************************************
// *****************************************************************************
// Section: MC PLL Estimator Parameter Initialization Routine
// *****************************************************************************
// *****************************************************************************
void mcApp_InitEstimParm(void)  
{
	mcApp_EstimParam.qLsDt = (float)(MOTOR_PER_PHASE_INDUCTANCE/LOOPTIME_SEC);
	mcApp_EstimParam.qRs = MOTOR_PER_PHASE_RESISTANCE;
	mcApp_EstimParam.qKFi = (float)(MOTOR_BACK_EMF_CONSTANT_Vpeak_PHASE_RAD_PER_SEC_ELEC);
	mcApp_EstimParam.qInvKFi_Below_Nominal_Speed = (float)INVKFi_BELOW_BASE_SPEED;
    mcApp_EstimParam.qLs_DIV_2_PI = (float) MOTOR_PER_PHASE_INDUCTANCE_DIV_2_PI;
    mcApp_EstimParam.qNominal_Speed = (float)NOMINAL_SPEED_RAD_PER_SEC_ELEC;
    mcApp_EstimParam.qDecimate_Nominal_Speed = (float)((float)NOMINAL_SPEED_RAD_PER_SEC_ELEC/10);
   	mcApp_EstimParam.qOmegaMr=0;
	 
    mcApp_EstimParam.qKfilterEsdq = KFILTER_ESDQ;
    mcApp_EstimParam.qVelEstimFilterK = KFILTER_VELESTIM;

    mcApp_EstimParam.qDeltaT = LOOPTIME_SEC;
    mcApp_EstimParam.RhoOffset = (45 * (M_PI/180));
}
