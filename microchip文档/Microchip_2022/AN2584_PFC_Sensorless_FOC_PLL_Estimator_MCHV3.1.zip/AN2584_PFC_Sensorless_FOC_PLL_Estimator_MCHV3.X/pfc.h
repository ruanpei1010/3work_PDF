/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.h

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

#ifndef _PFC_H    /* Guard against multiple inclusion */
#define _PFC_H

#define B0_AVG_FILT (float)1.3862780245480766E-6
#define B1_AVG_FILT (float)2.772556049096153E-6
#define B2_AVG_FILT (float)1.3862780245480766E-6
#define A1_AVG_FILT (float)1.9976410362200994
#define A2_AVG_FILT (float)-0.9976465813321974



typedef struct
{
 
    float avgOutput;
    float avgSquare;
    float measured;
       
}pfcParam_acVoltage;

typedef struct
{
    float avgOutput;
    float measured;
    float corrected;
     
}pfcParam_acCurrent;

typedef struct
{
    float measured;
    float filtered;
    float filterCoeff;

        
}pfcParam_dcBusVoltage;


typedef struct
{
    uint16_t duty;
    uint16_t samplePoint;
    float sampleCorrection;  // US
    int8_t rampRate;
    int8_t voltLoopExeRate;
    int8_t softStart;
    int8_t pfc_good;
    int8_t adcSwitchCount;
    int8_t firstPass;
    int8_t overcurrent_faultCount;
    int8_t overvoltage_faultCount;
    int8_t faultBit;
	int8_t pfcStart;
   
}pfcParam_AppControl;

typedef struct
{
    float B0;
    float B1;
    float B2;
    float A1;
    float A2;
    float y_n;
    float y_n_1;
    float y_n_2;
    float x_n;
    float x_n_1;
    float x_n_2;
    
} pfcParam_AvgFilterParam;


/* PFC Routines */
void pfcApp_ADCISRTasks(void);
void pfcApp_FaultCheck(void);
void pfcApp_VoltagePI(void);
void pfcApp_Init(void);
void pfcApp_DCMCompensation(void);
void pfcApp_AvgFilter(pfcParam_AvgFilterParam *pParam);

#endif /* _EXAMPLE_FILE_NAME_H */

/* *****************************************************************************
 End of File
 */
