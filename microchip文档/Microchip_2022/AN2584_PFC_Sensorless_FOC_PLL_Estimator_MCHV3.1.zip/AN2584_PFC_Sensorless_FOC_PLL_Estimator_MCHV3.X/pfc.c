#include <xc.h>
#include "pfc.h"
#include "userparams.h"
#include "peripherals.h"
#include "mc_Lib.h"


pfcParam_AppControl pfcApp_Control;

pfcParam_acVoltage pfcApp_acVoltageParam;
pfcParam_acCurrent pfcApp_acCurrentParam;
pfcParam_dcBusVoltage pfcApp_dcBusVoltageParam;
mcParam_PIController pfcApp_VoltagePIParam;
mcParam_PIController pfcApp_CurrentPIParam;

pfcParam_AvgFilterParam pfcApp_VacAvgFilter;
pfcParam_AvgFilterParam pfcApp_IacAvgFilter;
void pfcApp_Init(void)
{
  
    pfcApp_Control.firstPass = ENABLE;
    
    mcLib_InitPI(&pfcApp_VoltagePIParam);
    pfcApp_VoltagePIParam.qKp = (float)KP_PFC_VOLTAGE_LOOP;
    pfcApp_VoltagePIParam.qKi = (float)KI_PFC_VOLTAGE_LOOP;
    pfcApp_VoltagePIParam.qKc = (float)KC_PFC_VOLTAGE_LOOP;
    pfcApp_VoltagePIParam.qOutMax = 1;
    pfcApp_VoltagePIParam.qOutMin = 0;
    
    mcLib_InitPI(&pfcApp_CurrentPIParam);
    pfcApp_CurrentPIParam.qKp = (float)KP_PFC_CURRENT_LOOP;
    pfcApp_CurrentPIParam.qKi = (float)KI_PFC_CURRENT_LOOP;
    pfcApp_CurrentPIParam.qKc = (float)KC_PFC_CURRENT_LOOP;
    pfcApp_CurrentPIParam.qOutMax = 1;
    pfcApp_CurrentPIParam.qOutMin = 0;
    
    pfcApp_dcBusVoltageParam.filterCoeff = PFC_BUS_VOLTAGE_FILTER_COEFF;
    
   
    
    pfcApp_VacAvgFilter.B0 = B0_AVG_FILT;
    pfcApp_VacAvgFilter.B1 = B1_AVG_FILT;
    pfcApp_VacAvgFilter.B2 = B2_AVG_FILT;
    pfcApp_VacAvgFilter.A1 = A1_AVG_FILT;
    pfcApp_VacAvgFilter.A2 = A2_AVG_FILT;
    
    pfcApp_IacAvgFilter.B0 = B0_AVG_FILT;
    pfcApp_IacAvgFilter.B1 = B1_AVG_FILT;
    pfcApp_IacAvgFilter.B2 = B2_AVG_FILT;
    pfcApp_IacAvgFilter.A1 = A1_AVG_FILT;
    pfcApp_IacAvgFilter.A2 = A2_AVG_FILT;
    

}

/*
 This function implements a 2nd order IIR Filter with Cut-off frequency of 15Hz.
 This filter is used to calculate average values of AC line voltage and inductor
 current*/

inline void pfcApp_AvgFilter(pfcParam_AvgFilterParam *pParam)
{
   
   
   pParam->y_n  =(pParam->A1*pParam->y_n_1) ;
   pParam->y_n +=(pParam->A2*pParam->y_n_2);
   pParam->y_n +=(pParam->B0*pParam->x_n);
   pParam->y_n +=(pParam->B1*pParam->x_n_1);
   pParam->y_n +=(pParam->B2*pParam->x_n_2);

   pParam->y_n_2 = pParam->y_n_1;
   pParam->y_n_1 = pParam->y_n;
    
   pParam->x_n_2 = pParam->x_n_1;
   pParam->x_n_1 = pParam->x_n;
}


/**

This function checks for a input undervoltage/overvoltage, 
output undervoltage/overvoltage and overcurrent 
Faults

Summary: Function to perform Fault monitoring

@param  void
@return Fault status
*/
inline void pfcApp_FaultCheck(void)
 {
     if(pfcApp_Control.softStart == DISABLE)
     {
         //DC bus under voltage and over voltage faults
           if(pfcApp_dcBusVoltageParam.measured >= PFC_DC_BUS_OVER_VOLTAGE)
            {
                 pfcApp_Control.overvoltage_faultCount++;
               if(pfcApp_Control.overvoltage_faultCount  > 200)
               {
                   pfcApp_Control.faultBit = 1;
                   pfcApp_Control.overvoltage_faultCount=0;
               }
                
            }
         //AC input under voltage and over voltage faults
           else if((pfcApp_acVoltageParam.avgOutput >= PFC_AC_OVER_VOLTAGE || pfcApp_acVoltageParam.avgOutput <= PFC_AC_UNDER_VOLTAGE))
            {
                pfcApp_Control.faultBit = 1;
            }
           //AC input over current fault
           else if(pfcApp_acCurrentParam.avgOutput >= PFC_OVER_CURRENT)
            {
               pfcApp_Control.overcurrent_faultCount++;
               if(pfcApp_Control.overcurrent_faultCount  > 200)
               {
                   pfcApp_Control.faultBit = 1;
                   pfcApp_Control.overcurrent_faultCount=0;
               }
           }
           else
           {
               pfcApp_Control.overvoltage_faultCount=0;
               pfcApp_Control.overcurrent_faultCount=0;
           }
           if(pfcApp_Control.faultBit == 1)
           {
               LATGSET=0x8000; // Set LED D2 to indicate fault
               LATFCLR=0x0020; // Clear LED D19 
               disablePWM();                
               }
           }
        }

/**

in this Function the voltage loop PI related calculations are performed

Summary: Function to perform Outer loop Control

@param  void
@return PI output
*/
inline void pfcApp_VoltagePI(void)
{
        
 //Run voltage control loop for every 3Khz
        if (pfcApp_Control.voltLoopExeRate >= PFC_VOLTAGE_LOOP_PRESCALER)
        {
       
            // Filter DC Bus voltage remove 100Hz/ 120Hz Ripple
        pfcApp_dcBusVoltageParam.filtered = pfcApp_dcBusVoltageParam.filtered+
        ((pfcApp_dcBusVoltageParam.measured - pfcApp_dcBusVoltageParam.filtered) * pfcApp_dcBusVoltageParam.filterCoeff);
                
        pfcApp_VoltagePIParam.qInMeas = pfcApp_dcBusVoltageParam.filtered;
    
        mcLib_CalcPI(&pfcApp_VoltagePIParam);
                    
        pfcApp_Control.voltLoopExeRate  = 0;
        }
        else
        {
            pfcApp_Control.voltLoopExeRate ++;
            
        }
}



/**

This function generates the constant that is used to reshape the current waveform
into a better rectified sinusoidal wave under light load conditions and
zero crossings

Summary: Function to perform Average Voltage Calculation

@param  void
@return Correction factor
*/
inline void pfcApp_DCMCompensation(void)
{
    float temp;
    
    //DCM Mode Compensation = DutyCycle*VDC/(VDC-VAC)
    
    temp = (float)(pfcApp_dcBusVoltageParam.measured - pfcApp_acVoltageParam.measured);
    if(temp > 0)
    {
            //Dividing Vdc 
            temp = (float)( pfcApp_dcBusVoltageParam.measured/temp);
    
            //Calculating sample correction factor
            pfcApp_Control.sampleCorrection = (pfcApp_CurrentPIParam.qOut*temp) ;

        if(pfcApp_Control.sampleCorrection <= 0)
        {
            pfcApp_Control.sampleCorrection = 1;
        }
        
        if(pfcApp_Control.sampleCorrection >= 1)
        {
            pfcApp_Control.sampleCorrection = 1;
        }
    }
}


/**

in this Function the adc channels are configured to sample & convert the
MC signals and it also executes the PFC control loops

Summary: Function to perform PFC Control

@param  void
@return none
*/
inline void pfcApp_ADCISRTasks(void)
{
    float currentRef;
    float currentMeasured;
  
  
    pfcApp_dcBusVoltageParam.measured = (float)(ADCDATA10 * VOLTAGE_ADC_TO_PHY_RATIO);
    
   
    currentMeasured = (float)(ADCDATA0);
    
    pfcApp_acCurrentParam.measured = (float)((currentMeasured - AC_CURRENT_OFFSET)*PFC_ADC_CURR_SCALE); //2026

   if (pfcApp_acCurrentParam.measured <= 0)
   {
       pfcApp_acCurrentParam.measured =(float)PFC_ADC_CURR_SCALE;  
   }
    
    pfcApp_acVoltageParam.measured = (float)((ADCDATA4- AC_VOLTAGE_OFFSET) * PFC_AC_VOLTAGE_ADC_TO_PHY_RATIO);
    
        if (pfcApp_acVoltageParam.measured >= PFC_AC_MAX_VOLTAGE_PEAK)
    {
        pfcApp_acVoltageParam.measured = PFC_AC_MAX_VOLTAGE_PEAK;
    }

    //Average input Voltage Calculation
    pfcApp_VacAvgFilter.x_n = pfcApp_acVoltageParam.measured;
    pfcApp_AvgFilter(&pfcApp_VacAvgFilter);
    pfcApp_acVoltageParam.avgOutput = pfcApp_VacAvgFilter.y_n;
    
    pfcApp_acVoltageParam.avgSquare = (float)(pfcApp_VacAvgFilter.y_n*pfcApp_VacAvgFilter.y_n);
   
    //Average input Current Calculation
    pfcApp_IacAvgFilter.x_n = pfcApp_acCurrentParam.measured;
    pfcApp_AvgFilter(&pfcApp_IacAvgFilter);
    pfcApp_acCurrentParam.avgOutput = pfcApp_IacAvgFilter.y_n;

    if(((pfcApp_Control.firstPass == ENABLE && pfcApp_acVoltageParam.avgOutput >= VAVG_88V) || (pfcApp_Control.firstPass == DISABLE && pfcApp_dcBusVoltageParam.measured >= PFC_AC_MIN_VOLTAGE_PEAK))&& pfcApp_Control.faultBit==0)
    {

        if (pfcApp_Control.firstPass)
        {
            pfcApp_VoltagePIParam.qInRef  = pfcApp_dcBusVoltageParam.measured;
            pfcApp_Control.firstPass = DISABLE;
            pfcApp_Control.softStart = ENABLE;
        } 
        else
        {
            if (pfcApp_Control.softStart)
            {
                //check if Voltagereftemp is less than given reference voltage
                //and ramp it slowly
                
                if (pfcApp_VoltagePIParam.qInRef  <= PFC_DC_BUS_REF)
                {
                    if(pfcApp_Control.rampRate == 0)
                    {
                        pfcApp_VoltagePIParam.qInRef  = pfcApp_VoltagePIParam.qInRef  + PFC_SOFT_START_STEP_SIZE;
                        pfcApp_Control.rampRate = PFC_SOFT_START_RAMP_PRESCALER;
                        
                    }
                }
                else
                {
                    pfcApp_VoltagePIParam.qInRef  = PFC_DC_BUS_REF;
                    if(pfcApp_dcBusVoltageParam.measured >= PFC_DC_BUS_REF)
                    {
                        pfcApp_Control.softStart = DISABLE;
                        pfcApp_Control.pfc_good = 1;
                    
                    }
                    
                }
                pfcApp_Control.rampRate--;
            }
        }

        //Calling Voltage PI function
        pfcApp_VoltagePI();
        
        //Current reference Calculation is shown below
        // Current reference =
        //                (Voltage PI output)*(Vac Measured)*(1/Vavgsquare)*Kmul
        // where Kmul is calculated such that the current reference value
        // equals it maximum value at minimum line voltage
        // therefore Kmul = (Current reference maximum)/
        //            ((Voltage PI output max)*(Vac minimum)*(1/Vavgsquaremin))

       
         if(pfcApp_acVoltageParam.avgSquare<5861) // 5861 = avg(85VACrms)^2
       {
           pfcApp_acVoltageParam.avgSquare = 5861;
       }
        

       currentRef = (float) pfcApp_VoltagePIParam.qOut*pfcApp_acVoltageParam.measured;
        
       
       pfcApp_CurrentPIParam.qInRef  =  (float) ((currentRef*KMUL)/pfcApp_acVoltageParam.avgSquare) ;
       
       

        // Check if IndCurrent Reference exceeds Over Current Peak value
        if (pfcApp_CurrentPIParam.qInRef  > PFC_OVER_CURRENT_PEAK)
        {
            // If true, saturate it to Over Current Peak Value
            pfcApp_CurrentPIParam.qInRef  = PFC_OVER_CURRENT_PEAK;
        }
        else if (pfcApp_CurrentPIParam.qInRef  <= 0)
        {
            pfcApp_CurrentPIParam.qInRef  = 0;
        }
       

//Calling sample correction  function to shape the current waveform under light loads
        //and near zero crossings
        pfcApp_DCMCompensation();
//        //Multiplying the measured AC current with sample correction factor
        pfcApp_acCurrentParam.corrected = (float)(pfcApp_acCurrentParam.measured*pfcApp_Control.sampleCorrection);
//
        //if Vavg greater than average of 200Vrms
        if(pfcApp_acVoltageParam.avgOutput < VAVG_200V )
        {
           
                pfcApp_CurrentPIParam.qInMeas = pfcApp_acCurrentParam.corrected;
                        
        }
        else
        {
           // Current Error Calculation
          
                pfcApp_CurrentPIParam.qInMeas = pfcApp_acCurrentParam.measured;

        }
     
        //Calling current PI function
       mcLib_CalcPI(&pfcApp_CurrentPIParam);

        //Current loop PI output and Multiplying it with PWM period

        pfcApp_Control.duty  = (int16_t)(pfcApp_CurrentPIParam.qOut * MAX_PFC_DC);
   

        
        if (pfcApp_Control.duty  >= MAX_PFC_DC)//Check if Final Duty is greater than 95% of max.duty
        {
            pfcApp_Control.duty = MAX_PFC_DC;
        }
        //Check if Final Duty is less than MINOCDUTY count, in this case minimum
        //duty is limited to MINOCDUTY,since PTG is triggered on the low to high
        //transition of OC, duty cant be '0'
        else if (pfcApp_Control.duty  <= MIN_PFC_DC)
        {
            pfcApp_Control.duty  = MIN_PFC_DC;
        }
     
               
        /*Loading calculated value of pfc duty to PDC register*/
       
       PDC5 = (uint16_t) pfcApp_Control.duty;
       
       
        //Calling PFC fault function
        pfcApp_FaultCheck();
        
   }    

    return;
}