

extern unsigned short int  MCHP_ProfilingTimer();

