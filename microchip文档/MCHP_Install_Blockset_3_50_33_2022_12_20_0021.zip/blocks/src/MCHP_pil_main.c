/*
 * File: MCHP_pil_main.c
 *
 * Call pil_main function available in the library (from submodel compilation)
 *
 */

extern int pil_main();

int main(void) {
    pil_main();
}
