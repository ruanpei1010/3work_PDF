% MPLAB Device Blocks for Simulink
% Version 3.50.33 (R20xx) 20-Dec-2022
