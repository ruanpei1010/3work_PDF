classdef TargetApplicationFramework < rtw.pil.RtIOStreamApplicationFramework
    %TARGETAPPLICATIONFRAMEWORK is an example target connectivity configuration class

    %   Copyright 2007-2013 The MathWorks, Inc.

    methods
        function this = TargetApplicationFramework(componentArgs)
            narginchk(1, 1);
            % call super class constructor
            this@rtw.pil.RtIOStreamApplicationFramework(componentArgs);

            % To build the PIL application you must specify a main.c file.
            % The following PIL main.c files are provided and can be
            % added to the application framework via the "addPILMain"
            % method:
            %
            % 1) A main.c adapted for on-target PIL and suitable
            %    for most PIL implementations. Select by specifying
            %    'target' argument to "addPILMain" method.
            %
            % 2) A main.c adapted for host-based PIL such as the
            %    "mypil" host example. Select by specifying 'host'
            %    argument to "addPILMain" method.
            % this.addPILMain('target');

            % this.addPILMain('target');	%% This is a modified main, only calling the pil_main file written from our tlc code.


            % Additional source and library files to include in the build
            % must be added to the BuildInfo property

            % Get the BuildInfo object to update
            buildInfo = this.getBuildInfo;

            % add our custom MCHP main file
            MCHP_blks = which('MCHP_dsPIC_stf.tlc');    % Get MCHP blockset
            MCHP_blks_root = fileparts(fileparts(MCHP_blks));
            buildInfo.addSourcePaths([MCHP_blks_root filesep 'blocks' filesep 'src' ]);
            buildInfo.addSourceFiles([MCHP_blks_root filesep 'blocks' filesep 'src' filesep 'MCHP_pil_main.c' ]);


            % Add device driver files to implement the target-side of the
            % host-target rtIOStream communications channel
            % rtiostreamPath = fullfile(matlabroot, ...
            % 'rtw', ...
            % 'c', ...
            % 'src', ...
            % 'rtiostream', ...
            % 'rtiostreamtcpip');
            % buildInfo.addSourcePaths(rtiostreamPath);
            % buildInfo.addSourceFiles('rtiostream_tcpip.c');

            % % If using the lcc compiler on PC we must explicitly add the sockets
            % % library
            % if ispc
            % % Check for lcc compiler and add required libraries
            % isLCC = componentArgs.usingLcc;
            % if isLCC
            % TCPIPLib = fullfile(matlabroot, 'sys', 'lcc', 'lib', ...
            % 'wsock32.lib');
            % [libPath, libName, libExt] = fileparts(TCPIPLib);
            % priority = 1000;
            % precompiled = true;
            % linkOnly = true;
            % buildInfo.addLinkObjects([libName libExt], libPath, ...
            % priority, precompiled, linkOnly);
            % end

            % end
        end
    end
end
