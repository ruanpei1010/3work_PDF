UxV blockset is a third part toolbox developped by Lubin Kerhuel.

UxV blockset provides few function to work with Unmanned Vehicle.
It adds blocks for Mavlink, GPS, RC receiver protocol (SBUS, Smart Port, F.Port).
It adds functions to decode and analyze mavlink log files.

Run the .p script to install the blocks and features.

Microchip is not supporting this tool and could not be responsible for its use.
